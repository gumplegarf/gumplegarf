class PlaceholderItem extends HTMLElement {
  connectedCallback() {
    this.innerHTML = `
        <div class="grid-item">
            <img class="item-image" src="assets/item.png">
            <h3 class="artist-name">Artist Name</h3>
            <h2 class="item-name">Album Name</h2>
            <h3 class="price">£00.00</h3>
        `;
  }
}

customElements.define("placeholder-item", PlaceholderItem);
